#!/usr/bin/python
# -*- coding:utf8 -*-
import keras
import numpy as np
from keras.datasets import mnist
from keras.models import Model
from keras.layers import Dense, Input
from keras import regularizers
import matplotlib.pyplot as plt

batch_size = 256

epochs = 100

#数据预处理
(x_train, _), (x_test, _) = mnist.load_data() #去掉标签加载数据
x_train = x_train.astype('float32') #数据归一化
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
x_train = x_train.reshape((len(x_train), np.prod(x_train.shape[1:]))) #把28×28的数据平展成784大小的向量
x_test = x_test.reshape((len(x_test), np.prod(x_test.shape[1:])))
print(x_train.shape)
print(x_test.shape)

#建立自编码器模型
encoding_dim = 32  #将784维的数据压缩到32维，压缩率为24.5
input_img = Input(shape=(784,))
# 增加稀疏性
encoded = Dense(encoding_dim, activation='relu', activity_regularizer=regularizers.l1(10e-5))(input_img) #对输入的编码表示（压缩）
decoded = Dense(784, activation='sigmoid')(encoded) #输入的有损失重构
autoencoder = Model(inputs=input_img, outputs=decoded) #把输入映射到它的重构上

#建立单独的编码器模型
encoder = Model(inputs=input_img, outputs=encoded)

#建立单独的解码器模型
encoded_input = Input(shape=(encoding_dim,)) #编码维度是解码器的输入
decoded_layer = autoencoder.layers[-1]
decoder = Model(inputs=encoded_input, outputs=decoded_layer(encoded_input)) #把编码后的数据映射到最后的输出

#激活模型（compile）
autoencoder.compile(optimizer='adadelta', loss='binary_crossentropy') #配置模型参数，基于元素的二元交叉熵损失，和Adadelta优化算子
#训练模型
autoencoder.fit(x_train, x_train,
            batch_size=batch_size,
            epochs=epochs,
            shuffle=True,
            validation_data=(x_test, x_test))

# 可视化
encoded_imgs = encoder.predict(x_test)
decoded_imgs = decoder.predict(encoded_imgs)

n = 10
plt.figure(figsize=(20, 4))
for i in range(n):
     ax = plt.subplot(2, n, i+1) #display original
     plt.imshow(x_test[i].reshape(28, 28))
     plt.gray()
     ax.get_xaxis().set_visible(False)
     ax.get_yaxis().set_visible(False)

     ax = plt.subplot(2, n, i+1+n) #display reconstruction
     plt.imshow(x_test[i].reshape(28, 28))
     plt.gray()
     ax.get_xaxis().set_visible(False)
     ax.get_yaxis().set_visible(False)
plt.show()