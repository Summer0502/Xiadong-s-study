# encode and decode some digits ＃编码并解码一些数字
# note that we take them from the *test* set ＃注意我们从* test * set中取出它们
# use Matplotlib ＃使用Matplotlib

# Keras:基于Python的深度学习库。
# keras 本质上是对 thenao 或者 TensorFlow 的进一步封装（wrapper）

# 资料预处理
# keras 下的 packages
# 建立模型
from keras.layers import Input, Dense
# keras.layers（对 layer 的抽象），各种神经网络层，包括Dense全连接层，Dropout层，Cov2D 卷积层，等等。
# from keras.layers import Input：输入层（首字母大写，是一个类，表示输入层），类构造函数接受的参数分别有，（1）shape：tuple 类型，标识维度信息
# from keras.layers import Dense：全连接层，该类构造函数接收的参数分别有：（1）output_dim：下一层的神经元的数目（2）activation：字符串类型，默认为'linear'，所以一定要使用关键字参数的形式，对其进行设置；

# 建立模型
from keras.models import Model
# keras.models（对最终训练学习到的模型进行抽象）
# from keras.models import Model，其构造函数接受的参数分别为：（1）input，输入（2）output， 输出（3）很像 theano 下的 theano.function(...)
# Model 类更为重要的是其丰富的成员函数，ae = Model(input=…, output=…)：如下（1）（2）（3）
# （1）ae.compile()，参数列表主要有：①optimizer：字符串类型，adam/...②loss：字符串类型，mse/...
# （2）ae.fit()，用于正式的训练，参数列表主要有：①x, y：输入和输出，比如对于自编码器，x 和 y 是一致的；②shuffle：是否 shuffle 数据
# （3）ae.predict()：对单个的样本进行预测；
# 建立keras的相关模型如A，后续只需要使用model.add()方法，将各神经网络层加入模型即可

from keras.datasets import mnist
# 从keras 数据集导入mnist

import numpy as np
# numpy(Numerical Python extensions)是一个第三方的Python包，用于科学计算。这个库的前身是1995年就开始开发的一个用于数组运算的库。
# 经过了长时间的发展，基本上成了绝大部分Python科学计算的基础包，当然也包括所有提供Python接口的深度学习框架。
# 注意到在导入numpy的时候，我们将np作为numpy的别名。这是一种习惯性的用法

import matplotlib.pyplot as plt
# matplotlib.pyplot是一个有命令风格的函数集合，它看起来和MATLAB很相似。
# 每一个pyplot函数都使一副图像做出些许改变，例如创建一幅图，在图中创建一个绘图区域，在绘图区域中添加一条线等等。
# 在matplotlib.pyplot中，各种状态通过函数调用保存起来，以便于可以随时跟踪像当前图像和绘图区域这样的东西。
# 绘图函数是直接作用于当前axes（matplotlib中的专有名词，图形中组成部分，不是数学中的坐标系。）

from keras.callbacks import TensorBoard
# 要想查看keras的log日志又不是非常方便。这就有了与tensorboard结果来方便查看的想法

(x_train, _), (x_test, _) = mnist.load_data()
# 训练集，测试集收集非常方便
# keras中的mnist数据集已经被划分成了60,000个训练集，10,000个测试集的形式，按以上格式调用即可

# 准备MNIST数据，将其归一化和向量化，然后为后面训练做准备：
# 将X_train, X_test的数据格式转为float32
x_train = x_train.astype('float32') / 255.
# 把数据变成float32更精确
# 归一化
x_test = x_test.astype('float32') / 255.
x_train = x_train.reshape((len(x_train), np.prod(x_train.shape[1:])))
x_test = x_test.reshape((len(x_test), np.prod(x_test.shape[1:])))
# 打印出相关信息
print(x_train.shape)
print(x_test.shape)

encoding_dim = 32
# this is the size of our encoded representations # 这是我们编码表示的大小
# 32 floats -> compression of factor 24.5, assuming the input is 784 floats ＃32浮点数 - >因子24.5的压缩，假设输入为784浮点数
input_img = Input(shape=(784,))
# this is our input placeholder ＃这是我们的输入占位符

encoded = Dense(encoding_dim, activation='relu')(input_img)
# "encoded" is the encoded representation of the input ＃“encoded”是输入的编码表示
decoded = Dense(784, activation='sigmoid')(encoded)
# "decoded" is the lossy reconstruction of the input ＃“decoded”是输入的有损重构
# 对所有像素使用全连接层，输出为784，激活函数选用sigmoid

autoencoder = Model(inputs=input_img, outputs=decoded)
# this model maps an input to its reconstruction ＃此模型将输入映射到其重建
encoder = Model(inputs=input_img, outputs=encoded)
# this model maps an input to its encoded representation ＃此模型将输入映射到其编码表示

encoded_input = Input(shape=(encoding_dim,))
# create a placeholder for an encoded (32-dimensional) input ＃为编码（32维）输入创建占位符
decoder_layer = autoencoder.layers[-1]
# retrieve the last layer of the autoencoder model ＃检索自动编码器模型的最后一层

decoder = Model(inputs=encoded_input, outputs=decoder_layer(encoded_input))
# create the decoder model ＃创建解码器模型

autoencoder.compile(optimizer='adadelta', loss='binary_crossentropy')
# 模型我们使用交叉熵损失函数，最优化方法选用adadelta
# 下面我们训练自编码器，来重构MNIST中的数字，这里使用逐像素的交叉熵作为损失函数，优化器为adam

autoencoder.fit(x_train, x_train, epochs=50, batch_size=256, shuffle=True, validation_data=(x_test, x_test),callbacks=[TensorBoard(log_dir='/tmp/autoencoder')])
# 令人兴奋的训练过程
# batch_size 太小会导致训练慢，过拟合等问题，太大会导致欠拟合。所以要适当选择
# 50次完整迭代
# 50个epoch后，看起来我们的自编码器优化的不错了，损失是0.10，我们可视化一下重构出来的输出：即两组图片
# 只需要在fit的时候加上callbacks=[TensorBoard(log_dir='./tmp/log')] 这一句就可以将运行的结果记录下来了。
# 然后再cmd/terminal下命令： tensorboard --logdir=./temp/log 来浏览器进行查看。

encoded_imgs = encoder.predict(x_test)
decoded_imgs = decoder.predict(encoded_imgs)

n = 10  # how many digits we will display ＃我们将显示多少位数
plt.figure(figsize=(20, 4))
for i in range(n):
    # display original # 显示原始的
    ax = plt.subplot(2, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)

    # display reconstruction #显示重构的
    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(decoded_imgs[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
plt.show()